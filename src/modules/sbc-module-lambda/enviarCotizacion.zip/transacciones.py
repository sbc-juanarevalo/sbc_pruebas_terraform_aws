import os
import boto3
import json
import logging

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

# Define the client to interact with AWS Lambda
client = boto3.client('lambda')

arnProveedorBaseDatos = os.getenv("ARN_LAMBDA_PROVEEDOR_BASE_DATOS")


class transacciones:

    def consultarAvisoTransversal(self, numeroAviso):
        inputParams = {
            "numeroAviso": numeroAviso,
            "operacion": "consultarAviso"
        }
        response = client.invoke(
            FunctionName=arnProveedorBaseDatos,
            InvocationType='RequestResponse',
            Payload=json.dumps(inputParams)
        )
        if "Payload" in response:
            responseValidacion = json.load(response['Payload'])
            logger.info("Respuesta consulta de aviso en base de datos de transversal:")
            logger.info(responseValidacion)
            if "data" in responseValidacion and "error" in responseValidacion and "mensaje" in responseValidacion:
                return responseValidacion['data'], responseValidacion['error'], responseValidacion['mensaje']
            else:
                return None, True, "No se pudo consultar el aviso en la base de datos de transversal"
        else:
            return None, True, "No se pudo consultar el aviso en la base de datos de transversal"


    def consultarEstadoAvisoSimonId(self, estadoAvisoOrbikaId):
        inputParams = {
            "estadoAvisoOrbikaId": estadoAvisoOrbikaId,
            "operacion": "consultarEstadoAvisoSimonId"
        }
        response = client.invoke(
            FunctionName=arnProveedorBaseDatos,
            InvocationType='RequestResponse',
            Payload=json.dumps(inputParams)
        )
        if "Payload" in response:
            responseValidacion = json.load(response['Payload'])
            logger.info("Respuesta consulta del Estado Aviso Homologado Simon Id en base de datos de transversal:")
            logger.info(responseValidacion)
            if "data" in responseValidacion and "error" in responseValidacion and "mensaje" in responseValidacion:
                return responseValidacion['data'], responseValidacion['error'], responseValidacion['mensaje']
            else:
                return None, True, "No se pudo consultar el Estado Aviso Homologado Simon Id en base de datos de transversal"
        else:
            return None, True, "No se pudo consultar el Estado Aviso Homologado Simon Id en base de datos de transversal"

    def actualizarReserva(self,numeroAviso,idEnvio,numeroSiniestro,aseguradoraId,fechaEnvio,xmlRequest,xmlResponse,statusCode,estado):
        inputParams={
            "numeroAviso":str(numeroAviso),
            "idEnvio":idEnvio,
            "numeroSiniestro":numeroSiniestro,
            "aseguradoraId":aseguradoraId,
            "fechaEnvio":str(fechaEnvio),
            "request":str(xmlRequest),
            "response":str(xmlResponse),
            "statusCode":statusCode,
            "estado":estado,
            "operacion":"actualizarReserva"
            }

        response = client.invoke(
            FunctionName=arnProveedorBaseDatos,
            InvocationType='RequestResponse',
            Payload=json.dumps(inputParams)
        )

        if "Payload" in response:
            responseValidacion = json.load(response['Payload'])
            logger.info("Respuesta registro de reserva en base de datos de transversal:")
            logger.info(responseValidacion)
            if "data" in responseValidacion and "error" in responseValidacion and "mensaje" in responseValidacion:
                return responseValidacion['data'], responseValidacion['error'], responseValidacion['mensaje']
            else:
                return False, True, "No se pudo realizar el registro de la reserva en la base de datos de transversal"
        else:
            return False, True, "No se pudo realizar el registro de la reserva en la base de datos de transversal"

    def obtenerIdEnvio(self,numeroAviso):
        inputParams={
            "numeroAviso":str(numeroAviso),
            "operacion":"obtenerIdEnvio"
            }

        response = client.invoke(
            FunctionName=arnProveedorBaseDatos,
            InvocationType='RequestResponse',
            Payload=json.dumps(inputParams)
        )

        if "Payload" in response:
            responseValidacion = json.load(response['Payload'])
            logger.info("Respuesta de obtencion de IdEnvio para reserva desde base de datos de transversal:")
            logger.info(responseValidacion)
            if "data" in responseValidacion and "error" in responseValidacion and "mensaje" in responseValidacion:
                return responseValidacion['data'], responseValidacion['error'], responseValidacion['mensaje']
            else:
                return False, True, "No se pudo obtener el idEnvio desde la base de datos de transversal"
        else:
            return False, True, "No se pudo obtener el idEnvio desde la base de datos de transversal"


