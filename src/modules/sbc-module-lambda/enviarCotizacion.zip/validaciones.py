import re
from decimal import Decimal
import decimal

import logging

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

class validaciones:
    parteDecimal = ''
    parteEntera = ''

    def validarCampos(self, request):

        if len(str(request["numeroAviso"])) > 20:
            return True, 'El campo numeroAviso debe tener máximo 20 caracteres'
        if "numeroAviso" not in request:
            return True, 'El campo numeroAviso es requerido'
        if request["numeroAviso"] is None:
            return True, 'El campo numeroAviso es requerido'
        if int(request["numeroAviso"]) <= 0:
            return True, 'El campo numeroAviso debe ser mayor a 0 (cero)'

        if "numeroSiniestro" not in request:
            return True, 'El campo numeroSiniestro es requerido'
        if request["numeroSiniestro"] is None or request["numeroSiniestro"] == "":
            return True, 'El campo numeroSiniestro es requerido'
        if request["numeroSiniestro"] is not None and len(str(request["numeroSiniestro"])) > 30:
            return True, 'El campo numeroSiniestroo debe tener máximo 30 caracteres'

        if "placa" not in request:
            return True, 'El campo placa es requerido'
        if request["placa"] is None or request["placa"] == "":
            return True, 'El campo placa es requerido'
        if request["placa"] is not None and len(str(request["placa"])) > 20:
            return True, 'El campo placa debe tener máximo 20 caracteres'

        if "estadoAviso" not in request:
            return True, 'El campo estadoAviso es requerido'
        if request["estadoAviso"] is None:
            return True, 'El campo estadoAviso es requerido'
        if request["estadoAviso"] is not None and len(str(request["estadoAviso"])) > 2:
            return True, 'El campo estadoAviso debe tener máximo 2 caracteres'
        error, mensaje = self.validarEstadoAviso(request["estadoAviso"])
        if error:
            return True, mensaje

        if "pedidoInicial" not in request:
            return True, 'El campo pedidoInicial es requerido'
        if request["pedidoInicial"] is None:
            return True, 'El campo pedidoInicial es requerido'
        error, mensajeError = self.validarPedidoInicial(request["pedidoInicial"])
        if error:
            return error, mensajeError

        if "pedidoImprevistos" not in request:
            return True, 'El campo pedidoImprevistos es requerido'
        if request["pedidoImprevistos"] is None:
            return True, 'El campo pedidoImprevistos es requerido'
        error, mensajeError = self.validarImprevistos(request["pedidoImprevistos"])
        if error:
            return error, mensajeError

        ### Se deja inactivo este llamado por si en algun momento 
        ### Bolivar lo solicita
        
        if "posiciones" in request and not(request['posiciones'] in ("", None)):
            error, mensajeError = self.validacionCamposPosiciones(request["posiciones"])
            return error, mensajeError


        return False, ''

    def validarEstadoAviso(self, estadoAviso):
        estadoAvisoArray = [11,12,13,17,18]
        if estadoAviso in estadoAvisoArray:
            return False, ''
        else:
            return True, 'El campo estadoAviso debe ser: "11" o "12" o "13" o "17" o "18"'

    def validarTipoPieza(self, tipoPieza):
        tipoPiezaArray = [1, 2, 3]
        if tipoPieza in tipoPiezaArray:
            return False, ''
        else:
            return True, 'El campo tipoPieza debe ser:  1 o 2 o 3'

    def obtenerParteEnteraDecimal(self, numeroDecimal):
        if "." in str(numeroDecimal):
            self.parteEntera = str(numeroDecimal).split(".")[0]
            self.parteDecimal = str(numeroDecimal).split(".")[1]
        else:
            self.parteEntera = str(numeroDecimal)
        return self.parteEntera, self.parteDecimal

    def validarPedidoInicial(self, request):
        if "totalRepuestos" not in request:
            return True, 'El campo totalRepuestos es requerido'
        if request["totalRepuestos"] is None:
            return True, 'El campo totalRepuestos es requerido'
        parteEnteraTotalRepues, parteDecimalTotalRepues = self.obtenerParteEnteraDecimal(
            request["totalRepuestos"])
        if len(parteEnteraTotalRepues) > 13 or len(parteDecimalTotalRepues) > 2:
            return True, 'El campo totalRepuestos debe tener máximo 13 dígitos enteros y 2 dígitos decimales' 
        
        if "totalToT" not in request:
            return True, 'El campo totalToT es requerido'
        if request["totalToT"] is None:
            return True, 'El campo totalToT es requerido'
        parteEnteraTotalTot, parteDecimalTotalTot = self.obtenerParteEnteraDecimal(
            request["totalToT"])
        if len(parteEnteraTotalTot) > 13 or len(parteDecimalTotalTot) > 2:
            return True, 'El campo totalToT debe tener máximo 13 dígitos enteros y 2 dígitos decimales'
        
        if "totalManoObra" not in request:
            return True, 'El campo totalManoObra es requerido'
        if request["totalManoObra"] is None:
            return True, 'El campo totalManoObra es requerido'
        parteEnteraTotalManoObra, parteDecimalTotalManoObra = self.obtenerParteEnteraDecimal(
            request["totalManoObra"])
        if len(parteEnteraTotalManoObra) > 13 or len(parteDecimalTotalManoObra) > 2:
            return True, 'El campo totalManoObra debe tener máximo 13 dígitos enteros y 2 dígitos decimales'
            
        return False, ''

    def validarImprevistos(self, request):
        if "totalRepuestos" not in request:
            return True, 'El campo totalRepuestos es requerido'
        if request["totalRepuestos"] is None:
            return True, 'El campo totalRepuestos es requerido'
        parteEnteraTotalRepues, parteDecimalTotalRepues = self.obtenerParteEnteraDecimal(
            request["totalRepuestos"])
        if len(parteEnteraTotalRepues) > 13 or len(parteDecimalTotalRepues) > 2:
            return True, 'El campo totalRepuestos debe tener máximo 13 dígitos enteros y 2 dígitos decimales'
        
        if "totalToT" not in request:
            return True, 'El campo totalToT es requerido'
        if request["totalToT"] is None:
            return True, 'El campo totalToT es requerido'
        parteEnteraTotalTot, parteDecimalTotalTot = self.obtenerParteEnteraDecimal(
            request["totalToT"])
        if len(parteEnteraTotalTot) > 13 or len(parteDecimalTotalTot) > 2:
            return True, 'El campo totalToT debe tener máximo 13 dígitos enteros y 2 dígitos decimales'
        
        if "totalManoObra" not in request:
            return True, 'El campo totalManoObra es requerido'
        if request["totalManoObra"] is None:
            return True, 'El campo totalManoObra es requerido'
        parteEnteraTotalManoObra, parteDecimalTotalManoObra = self.obtenerParteEnteraDecimal(
            request["totalManoObra"])
        if len(parteEnteraTotalManoObra) > 13 or len(parteDecimalTotalManoObra) > 2:
            return True, 'El campo totalManoObra debe tener máximo 13 dígitos enteros y 2 dígitos decimales'
        
        return False, ''


    def validacionCamposPosiciones(self, request):
        logger.info("Construccion Lista de posiciones deducibles para el JSON")
        pos=0
        for posicion in request:

            if "idLinea" not in posicion:
                return True, 'El campo idLinea de la posicion ' + str(pos) + ' es requerido'
            if posicion["idLinea"] is None:
                return True, 'El campo idLinea de la posicion ' + str(pos) + ' es requerido'
            if int(posicion["idLinea"]) <= 0:
                return True, 'El campo idEnvio de la posicion ' + str(pos) + ' debe ser mayor a 0 (cero)'

            if "idPieza" not in posicion:
                return True, 'El campo idPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["idPieza"] is None or posicion["idPieza"] == "":
                return True, 'El campo idPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["idPieza"] is not None and len(posicion["idPieza"]) > 2000:
                return True, 'El campo idPieza de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'

            if "tipoPieza" not in posicion:
                return True, 'El campo tipoPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["tipoPieza"] is None:
                return True, 'El campo tipoPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["tipoPieza"] is not None and len(str(posicion["tipoPieza"])) > 1:
                return True, 'El campo tipoPieza de la posicion ' + str(pos) + ' debe tener máximo 1 caracteres'
            error, mensaje = self.validarTipoPieza(int(posicion["tipoPieza"]))
            if error:
                return True, mensaje

            if "descripcionPieza" not in posicion:
                return True, 'El campo descripcionPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["descripcionPieza"] is None or posicion["descripcionPieza"] == "":
                return True, 'El campo descripcionPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["descripcionPieza"] is not None and len(posicion["descripcionPieza"]) > 2000:
                return True, 'El campo descripcionPieza de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'

            if "referenciaPieza" not in posicion:
                return True, 'El campo referenciaPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["referenciaPieza"] is None or posicion["referenciaPieza"] == "":
                return True, 'El campo referenciaPieza de la posicion ' + str(pos) + ' es requerido'
            if posicion["referenciaPieza"] is not None and len(posicion["referenciaPieza"]) > 2000:
                return True, 'El campo referenciaPieza de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'

            if "cantidad" not in posicion:
                return True, 'El campo cantidad de la posicion ' + str(pos) + ' es requerido'
            if posicion["cantidad"] is None:
                return True, 'El campo cantidad de la posicion ' + str(pos) + ' es requerido'
            if int(posicion["cantidad"]) <= 0:
                return True, 'El campo cantidad de la posicion ' + str(pos) + ' debe ser mayor a cero (0)'
                    
            if "precioUnitario" not in posicion:
                return True, 'El campo precioUnitario de la posicion ' + str(pos) + ' es requerido'
            if posicion["precioUnitario"] is None:
                return True, 'El campo precioUnitario de la posicion ' + str(pos) + ' es requerido'
            parteEnteraPrecioUni, parteDecimalPrecioUni = self.obtenerParteEnteraDecimal(posicion["precioUnitario"])
            if len(parteEnteraPrecioUni) > 13 or len(parteDecimalPrecioUni) > 2:
                return True, 'El campo precioUnitario de la posicion ' + str(pos) + ' debe tener máximo 13 dígitos enteros y 2 dígitos decimales'

            if "identificadorConjunto" not in posicion:
                return True, 'El campo identificadorConjunto de la posicion ' + str(pos) + ' es requerido'
            if posicion["identificadorConjunto"] is None or posicion["identificadorConjunto"] == "":
                return True, 'El campo identificadorConjunto de la posicion ' + str(pos) + ' es requerido'
            if posicion["identificadorConjunto"] is not None and len(posicion["identificadorConjunto"]) > 2000:
                return True, 'El campo identificadorConjunto de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'
          
            if "nombreConjunto" in posicion:
                if posicion["nombreConjunto"] is not None and len(str(posicion["nombreConjunto"])) > 2000:
                    return True, 'El campo nombreConjunto de la posicion ' + str(pos) + ' debe tener máximo 2000 dígitos'

            if "origen" not in posicion:
                return True, 'El campo origen de la posicion ' + str(pos) + ' es requerido'
            if posicion["origen"] is None or posicion["origen"] == "":
                return True, 'El campo origen de la posicion ' + str(pos) + ' es requerido'
            if posicion["origen"] is not None and len(posicion["origen"]) > 2000:
                return True, 'El campo origen de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'        
           
            if "imprevisto" not in posicion:
                return True, 'El campo imprevisto de la posicion ' + str(pos) + ' es requerido'
            if posicion["imprevisto"] is None or posicion["imprevisto"] == "":
                return True, 'El campo imprevisto de la posicion ' + str(pos) + ' es requerido'
            if posicion["imprevisto"] is not None and len(str(posicion["imprevisto"])) > 1:
                return True, 'El campo imprevisto de la posicion ' + str(pos) + ' debe tener máximo 1 caracteres'

            if "codigoProveedor" not in posicion:
                return True, 'El campo codigoProveedor de la posicion ' + str(pos) + ' es requerido'
            if posicion["codigoProveedor"] is None or posicion["codigoProveedor"] == "":
                return True, 'El campo codigoProveedor de la posicion ' + str(pos) + ' es requerido'
            #if int(posicion["codigoProveedor"]) <= 0:
            #    return True, 'El campo codigoProveedor de la posicion ' + str(pos) + ' debe ser mayor a cero (0)'
            if posicion["codigoProveedor"] is not None and len(posicion["codigoProveedor"]) > 2000:
                return True, 'El campo codigoProveedor de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'

            if "nombreProveedor" not in posicion:
                return True, 'El campo nombreProveedor de la posicion ' + str(pos) + ' es requerido'
            if posicion["nombreProveedor"] is None or posicion["nombreProveedor"] == "":
                return True, 'El campo nombreProveedor de la posicion ' + str(pos) + ' es requerido'
            if posicion["nombreProveedor"] is not None and len(posicion["nombreProveedor"]) > 2000:
                return True, 'El campo nombreProveedor de la posicion ' + str(pos) + ' debe tener máximo 2000 caracteres'
            pos = pos + 1
        return False, ''

