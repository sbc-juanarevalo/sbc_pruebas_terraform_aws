# -*- coding: utf-8 -*-
import json
import os
from suds.client import Client
import boto3
import validaciones
import transacciones
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

import logging

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

numeroAvisoLogger=""

# Define the client to interact with AWS Lambda
client = boto3.client('lambda')
transaccionesObj = transacciones.transacciones()

def lambda_handler(event, context):


    try:
        validacionesObj = validaciones.validaciones()
        request = json.loads(event["body"])

        global numeroAvisoLogger
        numeroAvisoLogger="Número aviso: "+ str(request["numeroAviso"])

        logger.info(f"{numeroAvisoLogger}- Request enviarCotizacion: %s",request)

        error, mensajeError = validacionesObj.validarCampos(request)

        if error:
            errorBody = {
                "rtaMensaje": mensajeError
            }
            return {"body": json.dumps({
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": errorBody
            })}

        idEnvio, errorAviso, mensajeErrorAviso = consultarInformacionAvisoTransversal(request["numeroAviso"])

        if int(idEnvio) == 0:
            errorBody = {
               "rtaMensaje": mensajeErrorAviso
            }
            return {"body": json.dumps({
                            "statusCode": 400,
                            "headers": {"Content-Type": "application/json"},
                            "body": errorBody
            })}
        elif errorAviso:
             logger.info(f"{numeroAvisoLogger} - Mensaje de error: " + mensajeErrorAviso)
             errorBody = {
                "rtaMensaje": mensajeErrorAviso
             }
             return {"body": json.dumps({
                               "statusCode": 400,
                               "headers": {"Content-Type": "application/json"},
                               "body": errorBody
             })}
        else:
            estadoAvisoSimonId, errorEstadoAviso, mensajeErrorEstadoAviso = consultarEstadoAvisoSimonHomologadoId(request["estadoAviso"])
            if errorEstadoAviso:
                logger.info(f"{numeroAvisoLogger} - Mensaje de error: " + mensajeErrorEstadoAviso)
                errorBody = {
                    "rtaMensaje": mensajeErrorEstadoAviso
                }
                return {"body": json.dumps({
                                "statusCode": 400,
                                "headers": {"Content-Type": "application/json"},
                                "body": errorBody
                        })}

            return enviarPeticionAplicacion(request, estadoAvisoSimonId)
    except Exception as e:
        logger.error(e)
        return {"body": json.dumps({
                                "statusCode": 500,
                                "headers": {"Content-Type": "application/json"},
                                "body": '{"rtaMensaje":"Ocurrió un error interno en el servicio"}'
        })}


def enviarPeticionAplicacion(request, estadoAvisoSimonId):

    idEnvio, error, msg=transaccionesObj.obtenerIdEnvio(request["numeroAviso"])

    logger.info(f"{numeroAvisoLogger} - %s",msg)
    logger.info(f"{numeroAvisoLogger} - %s",idEnvio)

    if error:
        errorBody = {
                "rtaMensaje": mensajeErrorAviso
            }
        response={"body": json.dumps({
                       "statusCode": 400,
                       "headers": {"Content-Type": "application/json"},
                       "body": errorBody
        })}
        logger.info(f"{numeroAvisoLogger} - Mensaje enviado a admin:")
        logger.info(response)
        return response

    offset = timedelta(hours=5)
    fechaEnvio = datetime.now()-offset

    error, responseEnvio, xmlRequest, xmlResponse = enviarPeticionSimonEnviarCot(request, idEnvio, estadoAvisoSimonId)

    if error:

        respuestaServicio, statusCode = obtenerRespuestaPeticion(responseEnvio, request, idEnvio, fechaEnvio, xmlRequest, xmlResponse)

        logger.error(respuestaServicio)

        errorBody = {
                "rtaMensaje": responseEnvio
            }
        response= {"body": json.dumps({
                       "statusCode": statusCode,
                       "headers": {"Content-Type": "application/json"},
                       "body": errorBody
        })}
        logger.error(f"{numeroAvisoLogger} - Mensaje enviado a admin: ")
        logger.error(response)
        return response


    respuestaServicio, statusCode = obtenerRespuestaPeticion(responseEnvio, request, idEnvio, fechaEnvio, xmlRequest, xmlResponse)

    respuestaBody = {
        "rtaMensaje": respuestaServicio
    }
    response={"body": json.dumps({
                        "statusCode": statusCode,
                        "headers": {"Content-Type": "application/json"},
                        "body": respuestaBody
    })}

    logger.info(f"{numeroAvisoLogger} - Mensaje enviado a admin:")
    logger.info(response)

    return response


def enviarPeticionSimonEnviarCot(request, idEnvio, estadoAvisoSimonId):
    logger.info(f"{numeroAvisoLogger} - Petición enviada a SIMON con el metodo enviarCotización: ")
    cliente = getClienteSimonFromUri()
    # Se llena el objeto DataHeader del wsdl
    dataHeaderRequestType = crearDataHeader(cliente);
    # Se llena el objeto pedidoInicial del wsdl
    pedidoInicial = crearPedidoInicial(cliente, request["pedidoInicial"])
    # Se llena el objeto imprevistos del wsdl
    imprevistos = crearImprevistos(cliente, request["pedidoImprevistos"])
    # Se llena el arreglo posiciones del wsdl

    posiciones=''

    if "posiciones" in request and not(request['posiciones'] in ("", None)):
        posiciones = crearPosiciones(cliente, request["posiciones"])
    else:
        posiciones = crearPosicionesVacio(cliente)

    try:

        result = cliente.service.enviarCotizacion(dataHeaderRequestType, str(idEnvio), request["numeroAviso"], request["numeroSiniestro"], request["placa"], estadoAvisoSimonId, pedidoInicial, imprevistos, posiciones)
        xmlRequest=cliente.last_sent()
        xmlResponse=cliente.last_received()
        logger.info(result)
        logger.info(xmlRequest)
        logger.info(f"{numeroAvisoLogger} - Respuesta recibida de SIMON con el metodo enviarCotización: ")
        logger.info(xmlResponse)

    except Exception as e:
        logger.error(f"{numeroAvisoLogger} - Response desde error")
        logger.error(e)
        xmlRequest=cliente.last_sent()
        xmlResponse=cliente.last_received()
        logger.info(xmlRequest)
        return True, str(e) +" => No hubo respuesta desde Simon", xmlRequest, xmlResponse

    return False, result, xmlRequest, xmlResponse

def getClienteSimonFromUri():
    WDSL = os.getenv("URL_SIMON_ENVIAR_COTIZACION")
    LOCATION = os.getenv("URL_LOCATION_SIMON_ENVIAR_COTIZACION")
    return Client(WDSL, location=LOCATION, faults=False, timeout=int(os.getenv("TIMEOUT_REQUEST_SIMON")))

def crearPedidoInicial(cliente,request):
    pedidoInicial = cliente.factory.create("PedidoInicialReqTyp")
    pedidoInicial.totalRepuestos = request["totalRepuestos"]
    pedidoInicial.totalToT = request["totalToT"]
    pedidoInicial.totalManoObra = request["totalManoObra"]
    return pedidoInicial

def crearImprevistos(cliente,request):
    imprevistos = cliente.factory.create("ImprevistosReqTyp")
    imprevistos.totalRepuestos = request["totalRepuestos"]
    imprevistos.totalToT = request["totalToT"]
    imprevistos.totalManoObra = request["totalManoObra"]
    return imprevistos

def crearPosicionesVacio(cliente):
    atributos = cliente.factory.create("PosicionesReqTyp")
    return atributos

def crearPosiciones(cliente,request):
    posicionesArray = []
    for posicion in request:
        posiciones = cliente.factory.create("PosicionesReqTyp")
        posiciones.idLinea = posicion["idLinea"]
        posiciones.idPieza = posicion["idPieza"]
        posiciones.tipoPieza = posicion["tipoPieza"]
        posiciones.descripcionPieza = posicion["descripcionPieza"]
        posiciones.referenciaPieza = posicion["referenciaPieza"]
        posiciones.cantidad = posicion["cantidad"]
        posiciones.precioUnitario = posicion["precioUnitario"]
        posiciones.identificadorConjunto = posicion["identificadorConjunto"]
        posiciones.origen = posicion["origen"]
        posiciones.imprevisto = posicion["imprevisto"]
        posiciones.codigoProveedor = posicion["codigoProveedor"]
        posiciones.nombreProveedor = posicion["nombreProveedor"]
        posicionesArray.append(posiciones)
    atributos = posicionesArray
    return atributos

def obtenerRespuestaPeticion(resultResponse, request, idEnvio, fechaEnvio, xmlRequest,xmlResponse):

    aseguradoraId = int(os.getenv("ID_ASEGURADORA"))
    msg=''
    statusCode=0
    estado="Fallido"
    codRespuesta=4

    try:
        if hasattr(resultResponse[1]["DataHeader"],"errores"):
            msg=resultResponse[1]["DataHeader"]["errores"][0]["descripcion"]
            statusCode=resultResponse[0].value
            codRespuesta=resultResponse[1]["DataHeader"]["codRespuesta"]

        elif hasattr(resultResponse[1]["Data"],"mensajeSalida"):
            msg=resultResponse[1]["Data"]["mensajeSalida"]
            statusCode=resultResponse[0].value
            codRespuesta=resultResponse[1]["DataHeader"]["codRespuesta"]
        else:
            statusCode=resultResponse[0]
            msg=resultResponse[1]

    except:
        statusCode=500
        msg="No hubo respuesta desde Simon"


    if codRespuesta==0:
        estado="Exitoso"
    else:
        estado="Fallido"

    data, error, mensaje=transaccionesObj.actualizarReserva(request["numeroAviso"], idEnvio,request["numeroSiniestro"],aseguradoraId,fechaEnvio,xmlRequest,xmlResponse,statusCode,estado)
    if error:
        return mensaje, 400

    return msg,statusCode


def consultarInformacionAvisoTransversal(numeroAviso):
    avisoResponse, error, mensaje = transaccionesObj.consultarAvisoTransversal(numeroAviso)
    if error:
        return 0, True, mensaje, None
    if avisoResponse is not None:
        if len(avisoResponse) > 0:
            return avisoResponse[7], False, "Id Envio encontrado exitosamente"
        else:
            return 0, True, "Numero Aviso no encontrado en la base de datos transversal"
    else:
        return 0, False, "Numero Aviso no encontrado en la base de datos transversal"

def consultarEstadoAvisoSimonHomologadoId(estadoAvisoOrbikaId):
    estadoAvisoResponse, error, mensaje = transaccionesObj.consultarEstadoAvisoSimonId(estadoAvisoOrbikaId)
    if error:
        return -1, True, mensaje
    if estadoAvisoResponse is not None:
        if len(estadoAvisoResponse) > 0:
            if int(estadoAvisoResponse[2])==13 or int(estadoAvisoResponse[2])==14:
                return str(hex(int(estadoAvisoResponse[2]))[2:]).upper(), False, "Estado Aviso Simon Homologado Id encontrado exitosamente"
            else:
                return -1, True, "Estado Aviso Simon Homologado Id no encontrado en la base de datos transversal"
        else:
            return -1, True, "Estado Aviso Simon Homologado Id no encontrado en la base de datos transversal"
    else:
        return -1, True, "Estado Aviso Simon Homologado Id no encontrado en la base de datos transversal"

def crearDataHeader(cliente):
    dataHeader = cliente.factory.create('ns0:DataHeaderRequestType')
    dataHeader.modulo = int(os.getenv("MODULO"))
    dataHeader.proceso = int(os.getenv("PROCESO"))
    dataHeader.subProceso = int(os.getenv("SUB_PROCESO"))
    dataHeader.codCia = int(os.getenv("COD_CIA"))
    dataHeader.codSecc = int(os.getenv("COD_SECC"))
    dataHeader.codProducto = int(os.getenv("COD_PRODUCTO"))
    dataHeader.codUrs = os.getenv("COD_URS")
    dataHeader.entidadColocadora = int(os.getenv("ENTIDAD_COLOCADORA"))
    dataHeader.canal = int(os.getenv("CANAL"))
    dataHeader.sistemaOrigen = int(os.getenv("SISTEMA_ORIGEN"))
    dataHeader.pais = int(os.getenv("PAIS"))
    dataHeader.direccionIp = os.getenv("DIRECCION_IP")
    dataHeader.versionServicio = os.getenv("VERSION_SERVICIO")
    return dataHeader
